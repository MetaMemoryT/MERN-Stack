import React from 'react';
import style from './style';

class CommentForm extends React.Component {
  constructor(props){
    super(props);
    this.state = { author: '', text: ''};
    this.handleAuthorChange = this.handleAuthorChange.bind(this);
    this.handleTextChange = this.handleTextChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleAuthorChange(e){
    this.setState({ author : e.target.value});
  }

  handleTextChange(e){
    this.setState({ text: e.target.value});
  }
  handleSubmit(e){
    e.preventDefault();
    alert(this.state.author+ ' said ' + this.state.text);
    let author = this.state.author.trim();
    let text = this.state.text.trim();

    if(!text || !author){
      return;
    }
    this.props.onCommentSubmit({author: author, text, text});
    this.setState({author: '', text: ''});
  }
  render() {
    return (
      <form style= {style.commentForm} onSubmit={ this.handleSubmit}>
        <input style = {style.commentFormAuthor}
          onChange = {this.handleAuthorChange}
          value = {this.state.author}
          type = 'text'
          placeholder = 'Your Name..'/>
        <input style = {style.commentFormText}
          onChange = {this.handleTextChange}
          value = {this.state.text}
          type = 'text'
          placeholder = 'Say something..'/>
        <input style = { style.commentFormPost}
          type = 'submit'
          value = 'Post'/>
      </form>
    );
  }
}

export default CommentForm;
