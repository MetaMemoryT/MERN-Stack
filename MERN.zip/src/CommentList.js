import React from 'react';
import style from './style';
import Comment from './Comment';

class CommentList extends React.Component {
  render() {
    let CommentNodes = this.props.data.map(comment => {
      return (
        <Comment author= {comment.author} key={comment['_id']}>
        {comment.text}
        </Comment>
      )
    });
    return (
      <div style={style.CommentList}>
        { CommentNodes }
      </div>
    );
  }
}

export default CommentList;
