'use strict'

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const comments = require('./model/comments');
const User = require('./model/user');
const jwt = require('jsonwebtoken');

const app = express();
const router = express.Router();
const authRouter = express.Router();

const privateKey = 'dhimas';
const port = process.env.API_PORT || 3001;

mongoose.connect('mongodb://localhost/MERN');


app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());

app.get('/setup',function(req,res){

  var alfian = new User();
  alfian.name = 'Alfian';
  alfian.password = 'sabayota014';

  alfian.save(function(err){
    if(err) throw err;

    console.log('User saved successfully');
    res.json({success : true});
  })
})


app.use(function(req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT,DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers');
  res.setHeader('Cache-Control', 'no-cache');
  next();
});

authRouter.post('/authenticate',function(req,res){
  User.findOne({
    name : req.body.name
  }, function(err,user){
    if(err) throw err;
    if(!user){
      res.json({success : false});
    }else if(user){
      if(user.password != req.body.password){
        res.json({success : false, message : 'password slaah'});
      } else{
        var token = jwt.sign(user, privateKey);
        res.json({
          success : true,
          message : 'ini tokennya',
          token : token
        });
      }
    }
  });
});
router.use(function(req,res,next){
  var token = req.body.token || req.query.token || req.headers['x-access-token'];

  if(token){
    jwt.verify(token,privateKey,function(err,decoded){
      if(err){
        return res.json({success: false, message: 'failed to authenticate token'});
      }else{
        req.decoded = decoded;
        next();
      }
    });
  }else{
    return res.status(403).send({
      success : false,
      message : 'no token provided'
    });
  }
});
router.get('/', function(req,res){
  res.json({message : 'API INITIALIZED'});
});

router.route('/comments')
  .get(function(req,res){

    comments.find(function(err,comment){
      if(err)
        res.send(err);
      res.json(comment);
    });
  })
  .post(function(req,res){

    var c = new comments();
    c.author = req.body.author;
    c.text = req.body.text;

    c.save(function(err){
      if(err)
        res.send(err);
      res.json({message : 'comments successfully added'});
    });
  });

router.route('/comments/:comment_id')
  .put(function(req,res){

    comments.findById(req.params.comment_id,function(err, comment){
      if(err){
        res.send(err);
      }

      (req.body.author) ? comment.author = req.body.author : null;
      (req.body.text) ? comment.text = req.body.text : null;

      comment.save(function(err){
        if(err){
          res.send(err);
        }

        res.json({ message: 'comments has been updated'});
      });
    });
  })
  .delete(function(req,res){

    comments.remove({_id: req.params.comment_id},function(err,comment){
      if(err){
        res.send(err);
      }
      res.json({message: 'the comment has been deleted'});
    });
  });


app.use('/api',router);
app.use('/user',authRouter);

app.listen(port,function(){
  console.log('api running on port ${port}');
});
